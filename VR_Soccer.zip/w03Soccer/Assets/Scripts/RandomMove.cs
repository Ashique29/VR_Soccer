﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomMove : MonoBehaviour {

	public float forwardSpeed = 1.0f;
	public float turnSpeed = 100.0f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		float forwardBackward = Random.Range (-0.1f, 1.0f);
		float leftRight = Random.Range (-1.0f, 1.0f);

		this.gameObject.transform.position = this.gameObject.transform.position + forwardBackward * this.gameObject.transform.forward * forwardSpeed * Time.deltaTime;

		this.gameObject.transform.rotation = this.gameObject.transform.rotation * Quaternion.AngleAxis (leftRight * turnSpeed * Time.deltaTime, this.gameObject.transform.up);

	}
}
