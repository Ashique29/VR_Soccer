﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionTest : MonoBehaviour {

    // Use this for initialization
    void Start () {
		
	}
    public void OnCollisionEnter(Collision collision)
    {
        GameObject soccerBall;
        GameObject player = this.gameObject;
        soccerBall = GameObject.Find("Soccerball");
        soccerBall.transform.SetParent(player.transform, true);
        soccerBall.transform.position = player.transform.position + new Vector3(1, 1, 1);
        print("Soccer Ball Collied");
    }
    // Update is called once per frame
    void Update () {
		
	}
}
