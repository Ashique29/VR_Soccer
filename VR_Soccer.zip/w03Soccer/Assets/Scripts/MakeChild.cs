﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeChild : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //GameObject golla;
        //GameObject player = this.gameObject;
        //golla = GameObject.Find("Golla");
        //    golla.transform.SetParent(player.transform, true);
        //golla.transform.position = player.transform.position;

        //if(golla != null)
        //{
        //    //print("Golla Has");
        //}
        
        //player = this.gameObject.transform.Find("Ball").gameObject;
        //if (player != null) {
        //    print("Ball found");
        //}
        //else
        //{
        //    print("No balls");
        //}
	}
}
