﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour {

	public float speed = 5.0f;
	public float rotaionSpeed = 100.0f;
	// Use this for initialization
	void Start () {
		
	}

	//This Function will move an object either vertical axises or rotate it horizontically

	public void moveObject (float forwardSpeed, float turnSpeed)
	{
		float forwardBackward = Input.GetAxis ("Vertical"); 
		float leftRight = Input.GetAxis ("Horizontal");

        this.gameObject.transform.position = this.gameObject.transform.position + forwardBackward * this.gameObject.transform.forward * forwardSpeed * Time.deltaTime;

		this.gameObject.transform.rotation = this.gameObject.transform.rotation * Quaternion.AngleAxis (leftRight * turnSpeed * Time.deltaTime, this.gameObject.transform.up);
	}

	// Update is called once per frame
	void Update () {

		moveObject (speed, rotaionSpeed);
		//print ("Value is : "+ leftRight);



	}
}
